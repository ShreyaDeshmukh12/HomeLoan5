package com.cg.homeloan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.homeloan.dto.VisitDTO;
import com.cg.homeloan.entity.Visit;
import com.cg.homeloan.repository.IVisitRepository;
import com.cg.homeloan.util.VisitDTOConverter;

@Service
public class VisitServiceImpl implements IVisitService {

    @Autowired
    private IVisitRepository visitRepository;

    @Autowired
    private VisitDTOConverter visitConverter;

    @Override
    public VisitDTO scheduleVisit(VisitDTO visitDTO) {
        Visit visit = visitConverter.toVisitEntity(visitDTO);
        visit = visitRepository.save(visit);
        return visitConverter.toVisitDTO(visit);
    }
}
