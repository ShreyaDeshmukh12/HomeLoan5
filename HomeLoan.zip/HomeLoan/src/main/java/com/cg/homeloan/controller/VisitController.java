package com.cg.homeloan.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.cg.homeloan.dto.VisitDTO;
import com.cg.homeloan.service.IVisitService;

@RestController
@RequestMapping("/visit")
public class VisitController {

    @Autowired
    private IVisitService visitService;

    @PostMapping("/schedule")
    public VisitDTO scheduleVisit(@RequestBody VisitDTO visitDTO) {
        return visitService.scheduleVisit(visitDTO);
    }
}
