package com.cg.homeloan.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.homeloan.entity.Visit;

public interface IVisitRepository extends JpaRepository<Visit, Long> {
    // You can add custom query methods if needed
}
