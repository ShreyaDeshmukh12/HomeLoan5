package com.cg.homeloan.util;

import com.cg.homeloan.dto.VisitDTO;
import com.cg.homeloan.entity.Visit;
import org.springframework.stereotype.Component;

@Component
public class VisitDTOConverter {

    public VisitDTO toVisitDTO(Visit visit) {
        VisitDTO visitDTO = new VisitDTO();
        visitDTO.setVisitId(visit.getVisitId());
        visitDTO.setFitName(visit.getFitName());
        visitDTO.setLatName(visit.getLatName());
        visitDTO.setPhnNumber(visit.getPhnNumber());
        visitDTO.setEmlId(visit.getEmlId());
        return visitDTO;
    }

    public Visit toVisitEntity(VisitDTO visitDTO) {
        Visit visit = new Visit();
        visit.setVisitId(visitDTO.getVisitId());
        visit.setFitName(visitDTO.getFitName());
        visit.setLatName(visitDTO.getLatName());
        visit.setPhnNumber(visitDTO.getPhnNumber());
        visit.setEmlId(visitDTO.getEmlId());
        return visit;
    }
}
