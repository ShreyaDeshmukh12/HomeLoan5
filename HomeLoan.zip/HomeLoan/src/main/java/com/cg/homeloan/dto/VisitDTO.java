package com.cg.homeloan.dto;

import lombok.Data;

@Data
public class VisitDTO {
    private Long visitId;
    private String fitName;
    private String latName;
    private String phnNumber;
    private String emlId;
}
