package com.cg.homeloan.service;

import com.cg.homeloan.dto.ConnectDTO;

public interface IConnectService {
    ConnectDTO connectWithAgent(ConnectDTO connectDTO);
}
