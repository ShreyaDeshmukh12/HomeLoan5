package com.cg.homeloan.service;

import com.cg.homeloan.dto.VisitDTO;

public interface IVisitService {
    VisitDTO scheduleVisit(VisitDTO visitDTO);
}
